﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace final_project.Interfaces
{
    public interface ITime
    {
        public float getEstimationTime();
        public float getLoggedTime();

    }
}
